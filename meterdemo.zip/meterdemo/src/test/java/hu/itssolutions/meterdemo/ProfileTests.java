package hu.itssolutions.meterdemo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import hu.itsolutions.meterdemo.exceptions.MeteringValidationException;
import hu.itsolutions.meterdemo.exceptions.ProfileValidationException;
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.model.Profile;
import hu.itsolutions.meterdemo.utility.Constants;
import hu.itsolutions.meterdemo.utility.Constants.Months;
import hu.itsolutions.meterdemo.utility.MeteringReader;
import hu.itsolutions.meterdemo.utility.ProfileReader;
import io.restassured.RestAssured;
import io.restassured.response.Response;
public class ProfileTests {

    
    @Test
    public void whenGetAllMeterings_thenOK() {
        final Response response = RestAssured.get(Constants.API_ROOT);
        assertEquals(HttpStatus.OK.value(), response.getStatusCode());
    }
    
    @Test
    public void whenGetMeteringsById_thenOK() {
        final Metering metering = new Metering("2017", "0001", "A", Months.JAN, 1000);
        createMeteringAsUri(metering);

        final Response response = RestAssured.get(Constants.API_ROOT + "/");
        assertEquals(HttpStatus.OK.value(), response.getStatusCode());
        assertTrue(response.as(List.class)
            .size() > 0);
    }
    
    @Test
    @Ignore
    public void whenDeleteMetering_thenOk() {
        final Metering metering = new Metering("2017", "0001", "A", Months.JAN, 1000);
        final String location = createMeteringAsUri(metering);

        Response response = RestAssured.delete(location);
        assertEquals(HttpStatus.OK.value(), response.getStatusCode());

        response = RestAssured.get(location);
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatusCode());
    }
    
    private String createMeteringAsUri(Metering metering) {
        final Response response = RestAssured.given()
            .contentType(MediaType.APPLICATION_JSON_VALUE)
            .body(metering)
            .post(Constants.API_ROOT);
        return Constants.API_ROOT + "/id/true" + response.jsonPath().get("id");
    }
    
    @Test
    (expected = ProfileValidationException.class)
    public void testInvalidProfileReading() throws FileNotFoundException, ProfileValidationException {
    	ProfileReader pr = new ProfileReader();
    	List<Profile> profiles = pr.read(Constants.PROFILE_CSV_FILE_NAME_TEST_ERROR);
    }
    
    @Test
    (expected = MeteringValidationException.class)
    public void testInvalidMeterReading() throws FileNotFoundException, MeteringValidationException {
    	MeteringReader mr = new MeteringReader();
    	List<Metering> metering = mr.read(Constants.METERING_CSV_FILE_NAME_NOT_INCREMETAL_TEST_ERROR);
    }
    
}