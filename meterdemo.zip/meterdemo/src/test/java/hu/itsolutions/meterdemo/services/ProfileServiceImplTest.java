package hu.itsolutions.meterdemo.services;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import hu.itsolutions.meterdemo.model.Profile;
import hu.itsolutions.meterdemo.repository.ProfileRepositoryImpl;
import hu.itsolutions.meterdemo.utility.Constants.Months;

class ProfileServiceImplTest {

	@InjectMocks
	ProfileServiceImpl service;
	
	@Mock
	ProfileRepositoryImpl repository;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testFindProfileById() {
		Profile profile = new Profile();
		profile.setId(1l);
		profile.setProfileId("A");
		profile.setYear("2017");
		profile.setMonths(Months.JAN);
		profile.setFraction(0.28f);

		when(repository.findProfileById(anyLong())).thenReturn(profile);
	}

	@Test
	void testFindAllProfiles() {
		Profile profile1 = new Profile();
		profile1.setId(1l);
		profile1.setProfileId("A");
		profile1.setYear("2017");
		profile1.setMonths(Months.JAN);
		profile1.setFraction(0.28f);
		
		Profile profile2 = new Profile();
		profile2.setId(2l);
		profile2.setProfileId("B");
		profile2.setYear("2017");
		profile2.setMonths(Months.FEB);
		profile2.setFraction(0.17f);

		List<Profile> profiles = new ArrayList<Profile>();
		profiles.add(profile1);
		profiles.add(profile2);
		
		when(repository.findAllProfiles()).thenReturn(profiles);
	}

	@Test
	void testGetFractionByParams() {
		float fraction = 0.17f;
		when(repository.getFractionByParams("2017", Months.JAN, "A")).thenReturn(fraction);
	}

	@Test
	void testSaveProfile() {
		long id = 1L;
		
		Profile profile = new Profile();
		profile.setId(1l);
		profile.setProfileId("A");
		profile.setYear("2017");
		profile.setMonths(Months.JAN);
		profile.setFraction(0.28f);
		
		when(repository.saveProfile(profile)).thenReturn(id);
	}


}
