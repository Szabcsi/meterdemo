package hu.itsolutions.meterdemo.services;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import hu.itsolutions.meterdemo.dto.MeteringDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthsDetailsDto;
import hu.itsolutions.meterdemo.dto.MeteringYearTotalDto;
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.repository.MeteringRepositoryImpl;
import hu.itsolutions.meterdemo.utility.Constants.Months;

class MeteringServiceImplTest {

	@InjectMocks
	MeteringServiceImpl service;
	
	@Mock
	MeteringRepositoryImpl repository;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testFindAllMetering() {
		List<Metering> meterings = new ArrayList<Metering>();
		Metering metering1 = new Metering("2017", "0001", "A", Months.JAN, 1000);
		Metering metering2 = new Metering("2017", "0002", "B", Months.FEB, 1400);
		Metering metering3 = new Metering("2018", "0001", "A", Months.JAN, 1000);
		Metering metering4 = new Metering("2018", "0002", "B", Months.FEB, 1400);
		meterings.add(metering1);
		meterings.add(metering2);
		meterings.add(metering3);
		meterings.add(metering4);
		when(repository.findAllMetering()).thenReturn(meterings);
	}

	@Test
	void testFindById() {
		Metering metering = new Metering("2017", "0001", "A", Months.JAN, 1000);
		when(repository.findById(anyLong())).thenReturn(metering);
	}

	@Test
	void testFindByMeterId() {
		Metering metering = new Metering("2017", "0001", "A", Months.JAN, 1000);
		when(repository.findByMeterId(anyString())).thenReturn(metering);
	}

	@Test
	void testSaveMetering() {
		long id = 1L;
		Metering metering = new Metering("2017", "0001", "A", Months.JAN, 1000);
		when(repository.saveMetering(metering)).thenReturn(id);
	}

	@Test
	void testUpdateMeterPosition() {
		when(repository.updateMeterPosition(anyString(), anyString(), anyInt())).thenReturn(anyString());
	}

//	@Test
//	@Ignore
//	void testDeleteById() {
//		long id = 1l;
//		when(repository.deleteById(anyLong())).thenReturn(true);
//	}

	@Test
	void testFindByYear() {
		List<MeteringDto> meteringDto = new ArrayList<MeteringDto>();
		when(repository.findByYear("2017")).thenReturn(meteringDto);
	}

	@Test
	void testFindByYearTotal() {
		MeteringYearTotalDto meteringDto = new MeteringYearTotalDto("2018", 45000);
		when(repository.findByYearTotal("2018")).thenReturn(meteringDto);
	}

	@Test
	void testFindByYearMonthsDetails() {
		MeteringYearMonthsDetailsDto meteringDto = new MeteringYearMonthsDetailsDto();
		when(repository.findByYearMonthsDetails("2017")).thenReturn(meteringDto);
	}

	@Test
	void testFindByYearMonth() {
		MeteringYearMonthDto meteringDto = new MeteringYearMonthDto("2017", "JAN", 1000);
		when(repository.findByYearMonth("2017", Months.JAN)).thenReturn(meteringDto);
	}

}
