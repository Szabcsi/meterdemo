package hu.itsolutions.meterdemo.model;
/*
 * Client class for the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.util.HashMap;
import java.util.Map;

public class Client {

	private Address address;
	private Map<String, Metering> meterYears;

	public Client(String year, Address address, String id) {
		this.address = address;
		meterYears = new HashMap<String, Metering>();
		meterYears.put(year, new Metering());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		return true;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Map<String, Metering> getMeterYears() {
		return meterYears;
	}

	public void setMeterYears(Map<String, Metering> meterYears) {
		this.meterYears = meterYears;
	}

	@Override
	public String toString() {
		return "Client [address=" + address + ", meterYear=" + meterYears + "]";
	}

}
