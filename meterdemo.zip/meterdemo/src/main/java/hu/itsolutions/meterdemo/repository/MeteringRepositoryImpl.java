package hu.itsolutions.meterdemo.repository;
/*
 * Repository implementation class for metering.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import hu.itsolutions.meterdemo.dto.MeteringDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthsDetailsDto;
import hu.itsolutions.meterdemo.dto.MeteringYearTotalDto;
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.utility.Constants.Months;
import hu.itsolutions.meterdemo.utility.EntityToDtoConverter;
import hu.itsolutions.meterdemo.utility.MessageDecorator;

@Repository("meteringRepositoryImpl")
@Transactional
public class MeteringRepositoryImpl implements CustomMeteringRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<Metering> findAllMetering() {
		return (List<Metering>) entityManager.createNamedQuery("Metering.findAllMetering").getResultList();		
	}

	@Override
	public Metering findById(long id) {
		return (Metering) entityManager.createNamedQuery("Metering.findById").setParameter("id", id).getSingleResult();
	}

	@Override
	public Metering findByMeterId(String meterId) {
		return (Metering) entityManager.createNamedQuery("Metering.findByMeterId").setParameter("meterId", meterId).getSingleResult();
	}

	@Override
	public long saveMetering(Metering metering) {
		entityManager.persist(metering);
		return metering.getId();
	}

	@Override
	public String updateMeterPosition(String meterId, String year, int meterPosition) {
		entityManager.createNamedQuery("Metering.updateMeterPosition").setParameter("meterId", meterId).setParameter("year", year).setParameter("meterPosition", meterPosition).executeUpdate();
		return meterId;
	}

	@Override
	public boolean deleteById(long id) {
		entityManager.remove(this.findById(id));
		return true;
	}

	@Override
	public List<MeteringDto> findByYear(String year) {
		List<Metering> queryResult = entityManager.createNamedQuery("Metering.findByYear").setParameter("year", year).getResultList();
		List<MeteringDto> result = new ArrayList<MeteringDto>();
		for(Metering metering :queryResult) {
			result.add(EntityToDtoConverter.convert(metering));
		}
		return result;
	}
	
	@Override
	public MeteringYearTotalDto findByYearTotal(String year) {
		Integer queryResult = ((Number)entityManager.createNativeQuery("SELECT SUM(M.METERPOSITION) FROM METERING M WHERE M.YEAR = :year").setParameter("year", year).getSingleResult()).intValue();		
		MeteringYearTotalDto meterDto = new MeteringYearTotalDto();
		meterDto.setTotal(queryResult);
		meterDto.setYear(year);
		return meterDto;
	}
	
	@Override
	public MeteringYearMonthsDetailsDto findByYearMonthsDetails(String year) {
		List queryResult = entityManager.createNativeQuery("SELECT m.MONTH, SUM(m.METERPOSITION) FROM METERING m WHERE m.YEAR = :year GROUP BY m.MONTH ORDER BY m.MONTH ASC").setParameter("year", year).getResultList();
		return new MeteringYearMonthsDetailsDto();
	}
	
	@Override
	public MeteringYearMonthDto findByYearMonth(String year, Months months) {
		Integer queryResult = ((Number)entityManager.createNativeQuery("SELECT SUM(M.METERPOSITION) FROM METERING M WHERE M.YEAR = :year AND M.MONTH = :months").setParameter("year",year).setParameter("months", months.toString()).getSingleResult()).intValue();
		MeteringYearMonthDto meteringDto = new MeteringYearMonthDto();
		meteringDto.setMeterPosition(queryResult);
		meteringDto.setYear(year);
		meteringDto.setMonths(MessageDecorator.convertToLongMonthName(months));
		return meteringDto;
	}

}
