package hu.itsolutions.meterdemo;
/*
 * Initialization class of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.io.FileNotFoundException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import hu.itsolutions.meterdemo.exceptions.MeteringValidationException;
import hu.itsolutions.meterdemo.exceptions.ProfileValidationException;
import hu.itsolutions.meterdemo.logic.BusinessLogic;
import hu.itsolutions.meterdemo.model.Profile;
import hu.itsolutions.meterdemo.services.MeteringService;
import hu.itsolutions.meterdemo.services.ProfileService;
import hu.itsolutions.meterdemo.utility.Constants;
import hu.itsolutions.meterdemo.utility.ProfileReader;


@Component
public class InitMeterdemoApplication  implements InitializingBean {
	private static final Logger Logger  = LoggerFactory.getLogger(InitMeterdemoApplication.class);
     
	@Autowired
	ProfileService profileService;
	
	@Autowired
	MeteringService meteringService;
	
	/*
	 * After initialization process the Profile and Metering data
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		profileProcess();
		meteringProcess();
		Logger.info("Metering Demo Application Initialized");
	}
	
	/*
	 * Profile data persisted in the database prior the metering data is processed
	 * and validated.
	 */
	public void profileProcess() throws FileNotFoundException, ProfileValidationException {
		ProfileReader pr = new ProfileReader();
		List<Profile> profiles = pr.read(Constants.PROFILE_CSV_FILE_NAME);
		for(Profile profile: profiles) {
			profileService.saveProfile(profile);
		}
		Logger.info("Profiles process done");
	}
	/*
	 * Metering data process.
	 * Reads Profile data from the database. 
	 */
	public void meteringProcess() throws FileNotFoundException, MeteringValidationException {
		BusinessLogic logic = new BusinessLogic(profileService, meteringService);
		logic.meteringProcess();	
		Logger.info("Metering process done");
	}
	
}
