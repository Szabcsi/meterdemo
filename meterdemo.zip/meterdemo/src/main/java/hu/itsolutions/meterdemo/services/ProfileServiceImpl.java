package hu.itsolutions.meterdemo.services;
/*
 * Service implementation class for profile.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.itsolutions.meterdemo.model.Profile;
import hu.itsolutions.meterdemo.repository.ProfileRepositoryImpl;
import hu.itsolutions.meterdemo.utility.Constants.Months;

@Service("profileService")
public class ProfileServiceImpl implements ProfileService {

	@Autowired
	private ProfileRepositoryImpl repository;
	
	public List<Profile> findAllProfiles() {
        return repository.findAllProfiles();
    }

	public float getFractionByParams(String year, Months months, String profileId) {
		return repository.getFractionByParams(year, months, profileId);
	}
	
    public Profile findProfileById(Long id) {
        return repository.findProfileById(id);
    }

	@Override
	public long saveProfile(Profile profile) {
		return repository.saveProfile(profile);
	}

}
