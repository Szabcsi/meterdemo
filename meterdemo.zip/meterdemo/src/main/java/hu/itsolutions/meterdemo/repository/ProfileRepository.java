package hu.itsolutions.meterdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import hu.itsolutions.meterdemo.model.Profile;

public interface ProfileRepository extends JpaRepository<Profile, Long>, CustomProfileRepository {
    
}

