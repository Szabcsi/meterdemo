package hu.itsolutions.meterdemo.utility;
/*
 * Profile reader implementation class.
 * The file reading process closely tied to the validation.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import hu.itsolutions.meterdemo.exceptions.ProfileValidationException;
import hu.itsolutions.meterdemo.model.Profile;

public class ProfileReader extends AbstractProfileReader<Profile> {

	@Override
	public List<Profile> read(String file) throws FileNotFoundException, ProfileValidationException {
		List<String> data = readFile(file);
		List<Profile> profiles = new ArrayList<Profile>();
		float fraction = 0.0f;
		List<String> years = new ArrayList<String>();
		String yearStr = "";
		for (String str : data) {
			if(str.toUpperCase().contains("YEAR")) {
				String[] strArr = str.split(":");
				yearStr = strArr[1];
				years.add(yearStr);
			} else {
				String[] line = str.split(",");
				fraction = Float.parseFloat(line[2]);
				profiles.add(
						new Profile(yearStr, Constants.monthShortNames.get(line[0]), line[1], fraction));
			}
		}
		Set<String> profileIds = new HashSet<String>();
		List<Profile> sortedProfiles = new ArrayList<Profile>();
		for (Profile profile : profiles) {
			profileIds.add(profile.getProfileId());
		}
		
		for(String year : years) {
			List<Profile> yearList = profiles.stream().filter(f -> {
				return f.getYear().equals(year);
			}).collect(Collectors.toList());
			for (String profileId : profileIds) {
				List<Profile> profileList = yearList.stream().filter(f -> {
					return f.getProfileId().equals(profileId);
				}).collect(Collectors.toList());
				sortedProfiles.addAll(
						profileList.stream().sorted(Comparator.comparing(Profile::getMonths)).collect(Collectors.toList()));
			}
		}
			return validation(sortedProfiles, years);
	}
	
	
	@Override
	public List<Profile> validation(List<Profile> list, List<String> years) throws ProfileValidationException {
		float sum = 0.0f;
		Set<String> profileIds = new HashSet<String>();
		for (Profile profile : list) {
			profileIds.add(profile.getProfileId());
		}
		for(String year : years) {
			List<Profile> filty = list.stream().filter(f -> {
				return year.equals(f.getYear());
			}).collect(Collectors.toList());
			
			for(String profId : profileIds) {
				List<Profile> filtprof = filty.stream().filter(f -> {
					return profId.equals(f.getProfileId());
				}).collect(Collectors.toList());
			
				for(Profile prof:filtprof) {
					sum += prof.getFraction();
				}
				if(sum != 1.0f) {
					throw new ProfileValidationException(Constants.MSG_INVALID_FRACTION_VALUE);
				}
				sum = 0.0f;
			}
		}
		return list;
	}

	public static void main(String[] args) throws FileNotFoundException, ProfileValidationException {
		ProfileReader pr = new ProfileReader();
		List<Profile> profiles = pr.read("profiles-orig.csv");
		profiles.forEach(System.out::println);
	}

}
