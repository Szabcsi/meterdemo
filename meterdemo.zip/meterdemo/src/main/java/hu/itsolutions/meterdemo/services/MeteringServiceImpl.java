package hu.itsolutions.meterdemo.services;
/*
 * Service implementation class for metering.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.itsolutions.meterdemo.dto.MeteringDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthsDetailsDto;
import hu.itsolutions.meterdemo.dto.MeteringYearTotalDto;
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.repository.MeteringRepositoryImpl;
import hu.itsolutions.meterdemo.utility.Constants.Months;

@Service("MeteringServiceImpl")
public class MeteringServiceImpl implements MeteringService {

	@Autowired
	MeteringRepositoryImpl repository; 
	
	@Override
	public List<Metering> findAllMetering() {
		return repository.findAllMetering();
	}

	@Override
	public Metering findById(long id) {
		return repository.findById(id);
	}

	@Override
	public Metering findByMeterId(String meterId) {
		return repository.findByMeterId(meterId);
	}

	@Override
	public long saveMetering(Metering metering) {
		repository.saveMetering(metering);
		return metering.getId();
	}

	@Override
	public String updateMeterPosition(String meterId, String year, int meterPosition) {
		return repository.updateMeterPosition(meterId, year, meterPosition);
	}

	@Override
	public boolean deleteById(long id) {
		return repository.deleteById(id);
	}

	@Override
	public List<MeteringDto> findByYear(String year) {
		return repository.findByYear(year);
	}

	@Override
	public MeteringYearTotalDto findByYearTotal(String year) {
		return repository.findByYearTotal(year);
	}
	
	@Override
	public MeteringYearMonthsDetailsDto findByYearMonthsDetails(String year) {
		return repository.findByYearMonthsDetails(year);
	}
	
	@Override
	public MeteringYearMonthDto findByYearMonth(String year, Months month) {
		return repository.findByYearMonth(year, month);
	}

}
