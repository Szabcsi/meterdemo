package hu.itsolutions.meterdemo.exceptions;
/*
 * Checked exception class for validation.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
public class MeteringValidationException extends ValidationException {

	private static final long serialVersionUID = 1L;

	public MeteringValidationException(String errorMessage) {
		super(errorMessage);
	}

}
