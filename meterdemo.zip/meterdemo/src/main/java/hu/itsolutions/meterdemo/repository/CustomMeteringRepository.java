package hu.itsolutions.meterdemo.repository;

import java.util.List;

import hu.itsolutions.meterdemo.dto.MeteringDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthsDetailsDto;
import hu.itsolutions.meterdemo.dto.MeteringYearTotalDto;
import hu.itsolutions.meterdemo.dto.MeteringYearMonthDto;
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.utility.Constants.Months;

public interface CustomMeteringRepository {

	public List<Metering> findAllMetering();
	
	public Metering findById(long id);
	
	public Metering findByMeterId(String meterId);
	
	public long saveMetering(Metering metering);
	
	public String updateMeterPosition(String meterId, String year, int meterPosition);
	
	public boolean deleteById(long id);
	
	public List<MeteringDto> findByYear(String year);
	
	public MeteringYearTotalDto findByYearTotal(String year);
	
	public MeteringYearMonthsDetailsDto findByYearMonthsDetails(String year);
	
	public MeteringYearMonthDto findByYearMonth(String year, Months month);

}
