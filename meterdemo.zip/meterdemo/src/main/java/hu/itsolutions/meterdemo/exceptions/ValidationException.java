package hu.itsolutions.meterdemo.exceptions;
/*
 * Checked exception root class for the validation.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
public class ValidationException extends Exception {

	private static final long serialVersionUID = -2056279126184638806L;

	public ValidationException(String errorMessage) {
		super(errorMessage);
	}
}
