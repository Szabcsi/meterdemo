package hu.itsolutions.meterdemo.utility;
/*
 * Type independent abstract file reader.
 * Ensures the possibility to read any type data source.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.io.FileNotFoundException;
import java.util.List;

public abstract class AbstractFileReader<T> {
	
	public abstract List<T> readFile(String fileName) throws FileNotFoundException;

}
