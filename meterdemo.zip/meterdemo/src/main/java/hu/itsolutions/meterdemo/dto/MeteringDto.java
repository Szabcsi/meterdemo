package hu.itsolutions.meterdemo.dto;
/*
 * Data transfer class of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
public class MeteringDto {
	private String year;
	private String meterId;
	private String profileId;
	private String months;
	private Integer meterPosition;
	
	public MeteringDto(String year, String meterId, String profileId, String months, Integer meterPosition) {
		super();
		this.year = year;
		this.meterId = meterId;
		this.profileId = profileId;
		this.months = months;
		this.meterPosition = meterPosition;
	}

	public MeteringDto() {
		super();
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMeterId() {
		return meterId;
	}

	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public String getMonths() {
		return months;
	}

	public void setMonths(String months) {
		this.months = months;
	}

	public Integer getMeterPosition() {
		return meterPosition;
	}

	public void setMeterPosition(Integer meterPosition) {
		this.meterPosition = meterPosition;
	}

	@Override
	public String toString() {
		return "MeteringDto [year=" + year + ", meterId=" + meterId + ", profileId=" + profileId + ", months=" + months
				+ ", meterPosition=" + meterPosition + "]";
	}
	
}
