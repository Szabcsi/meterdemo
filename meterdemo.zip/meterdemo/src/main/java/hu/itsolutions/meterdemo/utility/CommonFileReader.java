package hu.itsolutions.meterdemo.utility;
/*
 * Common file reader for the descendant classes.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CommonFileReader extends AbstractFileReader<String> {

	public List<String> readFile(String fileName) throws FileNotFoundException {
		List<String> result = new ArrayList<String>();
		ClassLoader classLoader = new ProfileReader().getClass().getClassLoader();
		File file = new File(classLoader.getResource(fileName).getFile());
		Scanner scan = new Scanner(file);
		while (scan.hasNextLine()) {
			result.add(scan.nextLine());
		}
		scan.close();
		return result;
	}

}
