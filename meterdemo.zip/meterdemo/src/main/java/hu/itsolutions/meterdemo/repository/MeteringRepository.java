package hu.itsolutions.meterdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import hu.itsolutions.meterdemo.model.Metering;

public interface MeteringRepository extends JpaRepository<Metering, Long>, CustomMeteringRepository {
	
}

