package hu.itsolutions.meterdemo.dto;
/*
 * Data transfer class of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import hu.itsolutions.meterdemo.utility.Constants.Months;


public class ProfileDto {

	private String year;
	@Enumerated(EnumType.STRING)
	private Months months;
	private String profileId;
	private float fraction;
	
	public ProfileDto() {
		super();
	}
	
	public ProfileDto(String year, Months months, String profileId, float fraction) {
		super();
		this.year = year;
		this.months = months;
		this.profileId = profileId;
		this.fraction = fraction;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Months getMonths() {
		return months;
	}

	public void setMonths(Months months) {
		this.months = months;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public float getFraction() {
		return fraction;
	}

	public void setFraction(float fraction) {
		this.fraction = fraction;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((months == null) ? 0 : months.hashCode());
		result = prime * result + ((profileId == null) ? 0 : profileId.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfileDto other = (ProfileDto) obj;
		if (months != other.months)
			return false;
		if (profileId == null) {
			if (other.profileId != null)
				return false;
		} else if (!profileId.equals(other.profileId))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProfileFractionDto [year=" + year + ", months=" + months + ", profileId=" + profileId
				+ ", fraction=" + fraction + "]";
	}
	
}
