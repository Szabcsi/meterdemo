package hu.itsolutions.meterdemo.dto;
/*
 * Data transfer class of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MeteringYearMonthDto {
	private String year;
	private String months;
	private Integer meterPosition;
	
	public MeteringYearMonthDto(String year,String months, Integer meterPosition) {
		super();
		this.year = year;
		this.months = months;
		this.meterPosition = meterPosition;
	}

	public MeteringYearMonthDto() {
		super();
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonths() {
		return months;
	}

	public void setMonths(String months) {
		this.months = months;
	}

	public Integer getMeterPosition() {
		return meterPosition;
	}

	public void setMeterPosition(Integer meterPosition) {
		this.meterPosition = meterPosition;
	}

	@Override
	public String toString() {
		return "MeteringDto [year=" + year + ", months=" + months
				+ ", meterPosition=" + meterPosition + "]";
	}


}
