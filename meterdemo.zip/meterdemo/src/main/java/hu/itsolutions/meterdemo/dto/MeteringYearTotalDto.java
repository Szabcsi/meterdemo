package hu.itsolutions.meterdemo.dto;
/*
 * Data transfer class of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MeteringYearTotalDto {
	private String year;
	private Integer total;
	
	public MeteringYearTotalDto(String year, Integer total) {
		super();
		this.year = year;
		this.total = total;
	}

	public MeteringYearTotalDto() {
		super();
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "MeteringDto [year=" + year + ", total=" + total + "]";
	}

}
