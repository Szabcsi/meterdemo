package hu.itsolutions.meterdemo.logic;
/*
 * Main business logic of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.io.FileNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import hu.itsolutions.meterdemo.exceptions.MeteringValidationException;
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.services.MeteringService;
import hu.itsolutions.meterdemo.services.ProfileService;
import hu.itsolutions.meterdemo.utility.Constants;
import hu.itsolutions.meterdemo.utility.Constants.Months;
import hu.itsolutions.meterdemo.utility.MeteringReader;

@Component
public class BusinessLogic {
	private static final Logger Logger = LoggerFactory.getLogger(BusinessLogic.class);
	
	@Autowired
	MeteringService meteringService;
	
	@Autowired
	ProfileService profileService;
	
	
	public BusinessLogic(ProfileService profileService, MeteringService meteringService) {
		super();
		this.meteringService = meteringService;
		this.profileService = profileService;
	}
	/*
	 * Metering data process. 
	 * All the metering/consumption data will be nulled if it is not
	 * corresponding with the business logic.
	 * 
	 */
	public void meteringProcess() throws FileNotFoundException, MeteringValidationException {
		MeteringReader mr = new MeteringReader();
		List<Metering> meterings = mr.read(Constants.METERING_CSV_FILE_NAME);
		float fract = 0.0f;
		Integer yearCons = 0;
		String profileIdPrev="", profileIdAct="";
		String yearPrev="", yearAct="";
		Months monthAct=Months.JAN;
		Integer meterPositionAct = 0, meterPositionPrev = 0; 
		boolean first = true;
		for(Metering metering: meterings) {
			if(first) {
				yearAct = metering.getYear(); yearPrev = yearAct;
				profileIdAct = metering.getProfileId(); profileIdPrev= profileIdAct;
				yearCons = getConsumptionForYear(meterings, yearAct, profileIdAct);
				monthAct = metering.getMonths();
				meterPositionAct = metering.getMeterPosition(); meterPositionPrev = 0;
				first = false;
			}
			else {
				yearAct = metering.getYear();
				profileIdAct = metering.getProfileId();
				monthAct = metering.getMonths();
				meterPositionAct = metering.getMeterPosition();
			}
			
			fract = profileService.getFractionByParams(yearAct, monthAct, profileIdAct);
			if((!profileIdAct.equals(profileIdPrev) || !yearAct.equals(yearPrev))) {
				yearCons = getConsumptionForYear(meterings, yearAct, profileIdAct);
				meterPositionPrev = 0;
			}
			/*
			 * Checks whether the meter position/consumption data falls in the lower and upper bounds
			 * of fraction band.The fractions are determined for every month in the Profile.
			 * The fraction value is calculated from the total consumption of the year
			 * multiplied with the fraction for specific month.
			 * The 25% deviation from the fraction value results the fraction band.      
			 */
			if(metering.getMeterPosition() != null) {
				if(!((fract * yearCons * 0.75) < meterPositionAct - meterPositionPrev) && ((fract * yearCons * 1.25) > meterPositionAct - meterPositionPrev))
					metering.setMeterPosition(null);
			}
			meteringService.saveMetering(metering);
			yearPrev = yearAct;
			profileIdPrev= profileIdAct;
			meterPositionPrev = meterPositionAct;
		}
	}
	/*
	 * Calculates the total consumption for the year.
	 * Filters the incoming metering data for year and then profileId and sums the consumption/metering.  
	 */
	private Integer getConsumptionForYear(List<Metering> meterings, String year, String profileId) {
		Integer sum = 0;
		Integer prevConsumption = 0;
		List<Metering> yearList = meterings.stream().filter(f -> {
			return f.getYear().equals(year);
		}).collect(Collectors.toList());
		List<Metering> meteringList = yearList.stream().filter(f -> {
				return f.getProfileId().equals(profileId);
			}).collect(Collectors.toList());
		for (Metering metering : meteringList) {
			if(metering.getMeterPosition() == null)
				continue;
			sum = sum + metering.getMeterPosition() - prevConsumption;
			prevConsumption = metering.getMeterPosition();
		}
		return sum;
	}

}
