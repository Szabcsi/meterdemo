package hu.itsolutions.meterdemo.utility;
/*
 * Metering reader implementation class.
 * The file reading process closely tied to the validation.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import hu.itsolutions.meterdemo.exceptions.MeteringValidationException;
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.utility.Constants.Months;

public class MeteringReader extends AbstractMeteringReader<Metering> {
	
	public List<Metering> read(String file) throws FileNotFoundException, MeteringValidationException {
		List<String> data = readFile(file);
		List<Metering> meterings = new ArrayList<Metering>();
		Integer meterPosition = null;
		List<String> years = new ArrayList<String>();
		String yearStr = "";
		Months months = Months.JAN;
		for (String str : data) {
			if(str.toUpperCase().contains("YEAR")) {
				String[] strArr = str.split(":");
				yearStr = strArr[1];
				years.add(yearStr);
			} else {
				String[] line = str.split(",");
				meterPosition = Integer.parseInt(line[3]);
				months = Constants.monthShortNames.get(line[2]); 
				meterings.add(
						new Metering(yearStr, line[0], line[1], months, meterPosition));
			}
		}
		Set<String> profileIds = new HashSet<String>();
		List<Metering> sortedMeterings = new ArrayList<Metering>();
		for (Metering metering : meterings) {
			profileIds.add(metering.getProfileId());
		}
		
		for(String year : years) {
			List<Metering> yearList = meterings.stream().filter(f -> {
				return f.getYear().equals(year);
			}).collect(Collectors.toList());
			for (String profileId : profileIds) {
				List<Metering> meteringList = yearList.stream().filter(f -> {
					return f.getProfileId().equals(profileId);
				}).collect(Collectors.toList());
				sortedMeterings.addAll(
						meteringList.stream().sorted(Comparator.comparing(Metering::getMonths)).collect(Collectors.toList()));
			}
		}
		
		return validation(sortedMeterings, years);
	}

	@Override
	public List<Metering> validation(List<Metering> list, List<String> years) throws MeteringValidationException {
		Integer consAct = 0, consPrev = 0;
		Set<String> profileIds = new HashSet<String>();
		for (Metering metering : list) {
			profileIds.add(metering.getProfileId());
		}
		for(String year : years) {
			List<Metering> filty = list.stream().filter(f -> {
				return year.equals(f.getYear());
			}).collect(Collectors.toList());
			
			for(String profId : profileIds) {
				List<Metering> filtmet = filty.stream().filter(f -> {
					return profId.equals(f.getProfileId());
				}).collect(Collectors.toList());
			
				consPrev = 0;
				for(Metering meter:filtmet) {
					consAct = meter.getMeterPosition();
					if(consAct - consPrev < 0) {
						throw new MeteringValidationException(Constants.MSG_INVALID_CONSUMPTION_VALUE);
					}
					consPrev = consAct;
				}
			}
		}
		return list;
	}

	public static void main(String[] args) throws FileNotFoundException, MeteringValidationException {
		MeteringReader mr = new MeteringReader();
		List<Metering> meterings = mr.read("meterings-orig.csv");
		meterings.forEach(System.out::println);
	}
}
