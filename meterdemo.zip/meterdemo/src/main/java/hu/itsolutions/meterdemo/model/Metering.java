package hu.itsolutions.meterdemo.model;
/*
 * Metering class for the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import hu.itsolutions.meterdemo.utility.Constants.Months;

@Entity
@Table(name = "metering")
@NamedQueries({
	@NamedQuery(name = "Metering.findAllMetering", query="select m from Metering m"),
	@NamedQuery(name = "Metering.findById", query = "select m from Metering m where m.id = :id"),
	@NamedQuery(name = "Metering.findByYear", query = "select m from Metering m where m.year = :year"),
	@NamedQuery(name = "Metering.findByMeterId", query = "select m from Metering m where m.meterId = :meterId"),
	@NamedQuery(name = "Metering.updateMeterPosition", query = "update Metering m set m.meterPosition = :meterPosition where m.meterId = :meterId and m.year = :year")
})
public class Metering {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(name="YEAR")
	private String year;
	@Column(name="meterId")
	private String meterId;
	@Column(name="profileId")
	private String profileId;
	@Enumerated(EnumType.STRING)
	@Column(name="MONTH")
	private Months months;
	@Column(name="METERPOSITION")
	private Integer meterPosition;

	public Metering() {
		super();
	}
	
	public Metering(String year, String meterId, String profileId, Months months, Integer meterPosition) {
		super();
		this.year = year;
		this.meterId = meterId;
		this.profileId = profileId;
		this.months = months;
		this.meterPosition = meterPosition;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMeterId() {
		return meterId;
	}

	public void setMeterId(String meterId) {
		this.meterId = meterId;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public Integer getMeterPosition() {
		return meterPosition;
	}

	public void setMeterPosition(Integer meterPosition) {
		this.meterPosition = meterPosition;
	}
	
	public Months getMonths() {
		return months;
	}

	public void setMonths(Months months) {
		this.months = months;
	}

	
	@Override
	public String toString() {
		return "Metering [id=" + id + ", year=" + year + ", meterId=" + meterId + ", profileId=" + profileId
				+ ", months=" + months + ", meterPosition=" + meterPosition + "]";
	}

}
