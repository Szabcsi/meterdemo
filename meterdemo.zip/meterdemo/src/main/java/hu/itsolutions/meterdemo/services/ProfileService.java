package hu.itsolutions.meterdemo.services;

import java.util.List;

import hu.itsolutions.meterdemo.model.Profile;
import hu.itsolutions.meterdemo.utility.Constants.Months;

public interface ProfileService {
	
	public List<Profile> findAllProfiles();
	
	public float getFractionByParams(String year, Months months, String profileId);
	
	public Profile findProfileById(Long id);
	
	public long saveProfile(Profile profile);

}
