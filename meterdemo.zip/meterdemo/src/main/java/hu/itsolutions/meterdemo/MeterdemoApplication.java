package hu.itsolutions.meterdemo;
/*
 * Main class of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeterdemoApplication {
	private static final Logger LOG = LoggerFactory.getLogger(MeterdemoApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(MeterdemoApplication.class, args);
		LOG.info("Metering Demo Application Started");
	}

}
