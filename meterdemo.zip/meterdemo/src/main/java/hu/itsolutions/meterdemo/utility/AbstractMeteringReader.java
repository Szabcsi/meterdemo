package hu.itsolutions.meterdemo.utility;
/*
 * Type independent abstract file reader for Metering.
 * The file reading process closely tied to the validation.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.io.FileNotFoundException;
import java.util.List;

import hu.itsolutions.meterdemo.exceptions.MeteringValidationException;


public abstract class AbstractMeteringReader<T> extends CommonFileReader {
	
	public abstract List<T> read(String fileName) throws FileNotFoundException, MeteringValidationException; 
	
	public abstract List<T> validation(List<T> list, List<String> filter) throws MeteringValidationException; 
	
}
