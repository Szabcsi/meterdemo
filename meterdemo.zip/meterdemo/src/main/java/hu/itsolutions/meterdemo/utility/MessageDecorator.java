package hu.itsolutions.meterdemo.utility;
/*
 * Message decorator for month names.
 *  
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import hu.itsolutions.meterdemo.utility.Constants.Months;

public class MessageDecorator {

	public static String convertToLongMonthName(Months month) {
		return Constants.monthLongNames.containsKey(month.toString()) ? Constants.monthLongNames.get(month.toString()) : Constants.MSG_WRONG_MONTH_VALUE;
	}
}
