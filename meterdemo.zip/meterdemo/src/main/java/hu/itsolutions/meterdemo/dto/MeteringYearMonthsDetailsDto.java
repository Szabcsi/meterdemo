package hu.itsolutions.meterdemo.dto;
/*
 * Data transfer class of the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.util.HashMap;
import java.util.Map;
/*
 * Data transfer class of the application
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
public class MeteringYearMonthsDetailsDto {

	private String year;
	private Map<String, Integer> meterMonths = new HashMap<String, Integer>();
	
	public MeteringYearMonthsDetailsDto() {
		super();
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Map<String, Integer> getMeterMonths() {
		return meterMonths;
	}

	public void setMeterMonths(Map<String, Integer> meterMonths) {
		this.meterMonths = meterMonths;
	}

	@Override
	public String toString() {
		return "MeteringYearMonthsDetailsDto [year=" + year + ", meterMonths=" + meterMonths + "]";
	}
	
}
