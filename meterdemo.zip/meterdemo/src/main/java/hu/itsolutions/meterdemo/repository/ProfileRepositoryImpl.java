package hu.itsolutions.meterdemo.repository;
/*
 * Repository implementation class for profile.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import hu.itsolutions.meterdemo.model.Profile;
import hu.itsolutions.meterdemo.utility.Constants.Months;

@Repository("profileRepositoryImpl")
@Transactional
public class ProfileRepositoryImpl implements CustomProfileRepository {

	@PersistenceContext
	private EntityManager entityManager;	
	
	@Override
	public List<Profile> findAllProfiles() {
		return (List<Profile>)entityManager.createNamedQuery("Profile.findAllProfiles").getResultList();
	}

	@Override
	public float getFractionByParams(String year, Months months, String profileId) {
		Profile profile = (Profile)entityManager.createNamedQuery("Profile.getFractionByParams").setParameter("year", year).setParameter("months", months).setParameter("profileId", profileId).getSingleResult(); 
		return profile.getFraction();
	}
	
	@Override
	public Profile findProfileById(Long id) {
		return (Profile) entityManager.createNamedQuery("Profile.findProfileById").setParameter("id", id).getResultList();
	}

	@Override
	public long saveProfile(Profile profile) {
		entityManager.persist(profile);
		return profile.getId();
		
	}


}
