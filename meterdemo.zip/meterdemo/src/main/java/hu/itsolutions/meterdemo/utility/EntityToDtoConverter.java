package hu.itsolutions.meterdemo.utility;
/*
 * Entity to data transfer object converter.
 *  
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import hu.itsolutions.meterdemo.model.Metering;
import hu.itsolutions.meterdemo.dto.MeteringDto;
public class EntityToDtoConverter {

	public static MeteringDto convert(Metering metering) {
		MeteringDto meteringDto = new MeteringDto();
		meteringDto.setMeterId(metering.getMeterId());
		meteringDto.setProfileId(metering.getProfileId());
		meteringDto.setMonths(MessageDecorator.convertToLongMonthName(metering.getMonths()));
		meteringDto.setYear(metering.getYear());
		meteringDto.setMeterPosition(metering.getMeterPosition());
		return meteringDto;
	}
	
}
