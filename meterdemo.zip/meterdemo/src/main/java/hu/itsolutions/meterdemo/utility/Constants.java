package hu.itsolutions.meterdemo.utility;
/*
 * Constant values for the application.
 *
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import java.util.HashMap;
import java.util.Map;

public class Constants {

	public static final String MSG_INVALID_CONSUMPTION_VALUE = "Consumption is not incremental";
	public static final String MSG_INVALID_FRACTION_VALUE = "Fraction is not valid for year";
	public static final String MSG_CONSUMPTION_ALREADY_EXISTS = "Consumption already exists for this month";
	public static final String MSG_WRONG_MONTH_VALUE = "Wrong month value";
	
	public static final String PROFILE_CSV_FILE_NAME = "profiles-orig.csv";
	public static final String PROFILE_CSV_FILE_NAME_ERROR = "profiles-err.csv";
	public static final String PROFILE_CSV_FILE_NAME_TEST = "profiles-orig-test.csv";
	public static final String PROFILE_CSV_FILE_NAME_TEST_ERROR = "profiles-err-test.csv";
	
	public static final String METERING_CSV_FILE_NAME = "meterings-orig.csv";
	public static final String METERING_CSV_FILE_NAME_TEST = "meterings-orig-test.csv";
	public static final String METERING_CSV_FILE_NAME_OVER_CONSUMPTION_ERROR = "meterings-overconsumption-err.csv";
	public static final String METERING_CSV_FILE_NAME_OVER_CONSUMPTION_TEST_ERROR = "meterings-overconsumption-err-test.csv";
	public static final String METERING_CSV_FILE_NAME_NOT_INCREMETAL_ERROR = "meterings-not-incremental-err.csv";
	public static final String METERING_CSV_FILE_NAME_NOT_INCREMETAL_TEST_ERROR = "meterings-not-incremental-err-test.csv";
	
	
	public static final String API_ROOT = "http://localhost:8080/meterings";
	
	public static final String JANUARY_LONG_NAME ="January";
	public static final String FEBRUARY_LONG_NAME ="February";
	public static final String MARCH_LONG_NAME ="March";
	public static final String APRIL_LONG_NAME ="April";
	public static final String MAY_LONG_NAME ="May";
	public static final String JUNE_LONG_NAME ="June";
	public static final String JULY_LONG_NAME ="July";
	public static final String AUGUST_LONG_NAME ="August";
	public static final String SEPTEMBER_LONG_NAME ="September";
	public static final String OCTOBER_LONG_NAME ="October";
	public static final String NOVEMVER_LONG_NAME ="November";
	public static final String DECEMBER_LONG_NAME ="December";
	
	public static final String JANUARY_SHORT_NAME ="JAN";
	public static final String FEBRUARY_SHORT_NAME ="FEB";
	public static final String MARCH_SHORT_NAME ="MAR";
	public static final String APRIL_SHORT_NAME ="APR";
	public static final String MAY_SHORT_NAME ="MAY";
	public static final String JUNE_SHORT_NAME ="JUN";
	public static final String JULY_SHORT_NAME ="JUL";
	public static final String AUGUST_SHORT_NAME ="AUG";
	public static final String SEPTEMBER_SHORT_NAME ="SEP";
	public static final String OCTOBER_SHORT_NAME ="OCT";
	public static final String NOVEMVER_SHORT_NAME ="NOV";
	public static final String DECEMBER_SHORT_NAME ="DEC";
	
	public enum Months {
		JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC;
	}
	
	public static final Map<String, Months> monthShortNames = new HashMap<String, Months>();
	static 	{
			monthShortNames.put(JANUARY_SHORT_NAME, Months.JAN);
			monthShortNames.put(FEBRUARY_SHORT_NAME, Months.FEB);
			monthShortNames.put(MARCH_SHORT_NAME, Months.MAR);
			monthShortNames.put(APRIL_SHORT_NAME, Months.APR);
			monthShortNames.put(MAY_SHORT_NAME, Months.MAY);
			monthShortNames.put(JUNE_SHORT_NAME, Months.JUN);
			monthShortNames.put(JULY_SHORT_NAME, Months.JUL);
			monthShortNames.put(AUGUST_SHORT_NAME, Months.AUG);
			monthShortNames.put(SEPTEMBER_SHORT_NAME, Months.SEP);
			monthShortNames.put(OCTOBER_SHORT_NAME, Months.OCT);
			monthShortNames.put(NOVEMVER_SHORT_NAME, Months.NOV);
			monthShortNames.put(DECEMBER_SHORT_NAME, Months.DEC);
		}
	
	public static final Map<String, String> monthLongNames = new HashMap<String, String>();
	static {
			monthLongNames.put(JANUARY_SHORT_NAME, JANUARY_LONG_NAME);
			monthLongNames.put(FEBRUARY_SHORT_NAME, FEBRUARY_LONG_NAME);
			monthLongNames.put(MARCH_SHORT_NAME, MARCH_LONG_NAME);
			monthLongNames.put(APRIL_SHORT_NAME, APRIL_LONG_NAME);
			monthLongNames.put(MAY_SHORT_NAME, MAY_LONG_NAME);
			monthLongNames.put(JUNE_SHORT_NAME, JUNE_LONG_NAME);
			monthLongNames.put(JULY_SHORT_NAME, JULY_LONG_NAME);
			monthLongNames.put(AUGUST_SHORT_NAME, AUGUST_LONG_NAME);
			monthLongNames.put(SEPTEMBER_SHORT_NAME, SEPTEMBER_LONG_NAME);
			monthLongNames.put(OCTOBER_SHORT_NAME, OCTOBER_LONG_NAME);
			monthLongNames.put(NOVEMVER_SHORT_NAME, NOVEMVER_LONG_NAME);
			monthLongNames.put(DECEMBER_SHORT_NAME, DECEMBER_LONG_NAME);
		}
	}
