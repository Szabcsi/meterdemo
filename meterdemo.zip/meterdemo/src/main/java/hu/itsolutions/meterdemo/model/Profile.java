package hu.itsolutions.meterdemo.model;
/*
 * Profile class for the application.
 * 
 * authhor:beko.szabolcs@gmail.com
 * last updated:2019-04-29.
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import hu.itsolutions.meterdemo.utility.Constants.Months;

@Entity
@Table(name = "profile")
@NamedQueries({
	@NamedQuery(name = "Profile.findAllProfiles", query="select p from Profile p"),
	@NamedQuery(name = "Profile.findProfileById", query="select p from Profile p where p.id = :id"),
	@NamedQuery(name = "Profile.getFractionByParams", query="select p from Profile p where p.year = :year and p.months = :months and p.profileId = :profileId")
})

public class Profile {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column(name="year")
	private String year;
	@Enumerated(EnumType.STRING)
	@Column(name="months")
	private Months months;
	@Column(name="profileid")
	private String profileId;
	@Column(name="fraction")
	private float fraction;
	
	public Profile() {
		super();
	}

	public Profile(String year, Months months, String profileId, float fraction) {
		super();
		this.year = year;
		this.months = months;
		this.profileId = profileId;
		this.fraction = fraction;
	}
	
	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Months getMonths() {
		return months;
	}

	public void setMonths(Months months) {
		this.months = months;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public float getFraction() {
		return fraction;
	}

	public void setFraction(float fraction) {
		this.fraction = fraction;
	}

	@Override
	public String toString() {
		return "Profile [id=" + id + ", year=" + year + ", months=" + months + ", profileId=" + profileId
				+ ", fraction=" + fraction + "]";
	}

}
